//package com.maxlifeinsurance.mpro.daoimpl;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.ResourceBundle;
//
//import org.bson.Document;
//import org.json.JSONObject;
//import org.reflections.ReflectionUtils;
//
//import com.google.gson.Gson;
//import com.google.gson.JsonObject;
//import com.maxlifeinsurance.mpro.config.DbConfig;
//import com.maxlifeinsurance.mpro.dao.AxisMproDao;
//import com.maxlifeinsurance.mpro.dto.AxisMproDto;
//import com.maxlifeinsurance.mpro.utils.Constants;
//import com.maxlifeinsurance.mpro.utils.Queries;
//import com.mongodb.BasicDBObject;
//import com.mongodb.DBCursor;
//import com.mongodb.client.FindIterable;
//import com.mongodb.client.MongoCollection;
//import com.mongodb.client.MongoCursor;
//import com.mongodb.client.MongoDatabase;
//import com.mongodb.client.model.Filters;
//import com.mongodb.client.model.Projections;
//import com.mongodb.util.JSON;
//
//public class AxisMproDaoImpl implements AxisMproDao{
//
//	static ResourceBundle application = ResourceBundle.getBundle(Constants.APPLICATION);
//	
//	DbConfig dbConfig = new DbConfig();
//	private String sgMongoDbName=application.getString(Constants.MONGODB_DBNAME);
//
//	@Override
//	public List<AxisMproDto> getAxisMproData(String context){
//
//		List<AxisMproDto> axisMproDataList = null;
//		try {
////			context.getLogger().log("sgMongoDbName :: "+sgMongoDbName);
//			axisMproDataList= getData( context);
//			System.out.println("proposalNum found "+axisMproDataList);
////		context.getLogger().log("proposalNum found "+axisMproDataList);
//		}
//		catch(Exception ex) {
////			context.getLogger().log("Exception in getAxisMproData method :: "+axisMproDataList);
//			System.out.println("Exception in getAxisMproData method :: "+axisMproDataList);
//		}
//		
//		return axisMproDataList;
//	}
//
//	
//	public List<AxisMproDto> getData( String context) {
//		
//		MongoDatabase db = dbConfig.getDbConnection(sgMongoDbName/*, context*/);
//		MongoCollection coll = db.getCollection("proposal");
//		List<AxisMproDto> axisMproDataList=null;
//		try{
////			Document queryFilter=new Document();
////			context.getLogger().log("get all document data ");
//			axisMproDataList = getAllDocuments(db, coll/*, context*/);
////			queryFilter.append(Constants.PROPOSAL_NO,new Document("$regex", "^9"));
////			queryFilter.append(Constants.IS_USED, false);
////			Document sort=new Document(Constants.PROPOSAL_NO,-1);
////			Document documentUpdate=new Document();
////			Document updateObj=new Document();
////			updateObj.append(Constants.IS_USED,true);
////			updateObj.append(Constants.SOURCE_APPLICATION,"MAPP");
////			updateObj.append(Constants.CHANNEL, "");
////			updateObj.append(Constants.FAMILY_TYPE,"trad");
////			updateObj.append(Constants.CONSUMER_ID,"");
////			updateObj.append(Constants.UPDATE_ON,new Date());
////			documentUpdate.append("$set", updateObj);
////			FindOneAndUpdateOptions options=new FindOneAndUpdateOptions();
////			options.sort(sort);
////			Object resturnObj=coll.findOneAndUpdate( queryFilter, documentUpdate,options);
////			return ((Document)resturnObj).get(Constants.PROPOSAL_NO)+"";
//			
//		}catch(Exception e){
//			System.out.println("Creating Exception while getting proposal number from Mongo DB "+e.getMessage());
//			return null;
//		}
//		System.out.println("returning success response");
//		return axisMproDataList;
//		
//	}
//	
//
//	private static List<AxisMproDto> getAllDocuments(MongoDatabase db, MongoCollection<Document> col/*, Context context*/) {
//		System.out.println("Fetching all documents from the collection");
// 
//		List<AxisMproDto> axisMproDataList = new ArrayList<AxisMproDto>();
//        String srch_name = "A";
//        FindIterable<Document> fi = col.find(Filters.eq("channelDetails.channel", srch_name))
//        		.projection(Projections.include(Queries.POLICY_NUMBER,Queries.TRANSACTION_ID,Queries.STAGE,
//        				Queries.CREATED_DATE, Queries.BRANCH_CODE, Queries.FIRST_NAME));
//       
//        
//        MongoCursor<Document> cursor = fi.iterator();
//        long txnId;
//        
//        try {
//            while(cursor.hasNext()) {
//                System.out.println(cursor.next().toJson());
//                txnId=(cursor.next().getLong("transactionId"));
//                axisMproDataList.add(putData(cursor.next()));
//                System.out.println("txnid :: "+txnId);
//            }
//        } finally {
//            cursor.close();
//        }
//        
//        
//		return axisMproDataList;
//    }
//
//
//	private static AxisMproDto putData(Document doc) {
//		AxisMproDto axisMproDto = new AxisMproDto();
//		try {
//			
////			axisMproDto.setPolicyNumber(doc.getJSONObject("applicationDetails").get("policyNumber").toString());
////			axisMproDto.setTransactionId(doc.getJSONObject("transactionId").toString());
////			axisMproDto.setBranchCode(doc.getJSONObject("channelDetails").getString("branchCode"));
////			axisMproDto.setCreatedTime(doc.getJSONObject("applicationDetails").get("createdTime").toString());
////			axisMproDto.setStage(doc.getJSONObject("applicationDetails").getString("stage").toString());
////			axisMproDto.setFirstName(doc.getJSONObject("partyInformation").getJSONArray("basicDetails").get(0).toString());
//			
//			axisMproDto.setPolicyNumber(doc.get("applicationDetails",Document.class).getString("policyNumber"));
//			axisMproDto.setTransactionId(doc.getLong("transactionId").toString());
//			axisMproDto.setBranchCode(doc.get("channelDetails", Document.class).getString("branchCode"));
//			axisMproDto.setCreatedTime(doc.get("applicationDetails", Document.class).getDate("createdTime").toString());
//			axisMproDto.setStage(doc.get("applicationDetails", Document.class).getString("stage").toString());
//			String ls = doc.get("partyInformation", Document.class).get(0).toString();
//			Gson g = new Gson(); 
//			
//			Object p = g.fromJson(ls, Object.class);
//
//			axisMproDto.setFirstName(((Document) p).get("basicDetails",  Document.class).getString("firstName"));
//		}
//		catch(Exception e) {
//			System.out.println("Exception in putData method" + e);
//		}
//		
//		return axisMproDto;
//	}
//	
//}
