package com.maxlifeinsurance.mpro.dto;

import java.io.Serializable;

import com.maxlifeinsurance.mpro.utils.MultiFormatDate;

public class AxisLeadIdReportDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String transactionId;
	private String createdTime;
	private String policyNumber;
	private String leadId;
	private String channel;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = MultiFormatDate.formatDateInMongoDateFormat(createdTime);
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	@Override
	public String toString() {
		return "AxisLeadIdReportDTO [transactionId=" + transactionId + ", createdTime=" + createdTime
				+ ", policyNumber=" + policyNumber + ", leadId=" + leadId + ", channel=" + channel + "]";
	}
	
	
}
