package com.maxlifeinsurance.mpro.commonentity;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"soaCorrelationId",
"soaAppId"
})
public class SoaHeader implements Serializable{

	private static final long serialVersionUID = -2499939894729077405L;
	@JsonProperty("soaCorrelationId")
	private String soaCorrelationId;
	@JsonProperty("soaAppId")
	private String soaAppId;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("soaCorrelationId")
	public String getSoaCorrelationId() {
	return soaCorrelationId;
	}

	@JsonProperty("soaCorrelationId")
	public void setSoaCorrelationId(String soaCorrelationId) {
	this.soaCorrelationId = soaCorrelationId;
	}

	@JsonProperty("soaAppId")
	public String getSoaAppId() {
	return soaAppId;
	}

	@JsonProperty("soaAppId")
	public void setSoaAppId(String soaAppId) {
	this.soaAppId = soaAppId;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}
}
