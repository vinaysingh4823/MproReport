//package com.maxlifeinsurance.mpro.serviceimpl;
//
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.ResourceBundle;
//import java.util.regex.Pattern;
//
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.CellStyle;
//import org.apache.poi.ss.usermodel.Font;
//import org.apache.poi.ss.usermodel.HorizontalAlignment;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//
//import com.maxlifeinsurance.mpro.dao.AxisMproDao;
//import com.maxlifeinsurance.mpro.daoimpl.AxisMproDaoImpl;
//import com.maxlifeinsurance.mpro.dto.AxisMproDto;
//import com.maxlifeinsurance.mpro.service.AxisMproService;
//import com.maxlifeinsurance.mpro.service.CommunicationService;
//import com.maxlifeinsurance.mpro.utils.Constants;
//import com.maxlifeinsurance.mpro.utils.StringConstants;
//import com.maxlifeinsurance.mpro.utils.StringUtility;
//import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
//
//import net.lingala.zip4j.core.ZipFile;
//import net.lingala.zip4j.model.ZipParameters;
//import net.lingala.zip4j.util.Zip4jConstants;
//
//public class AxisMproServiceImpl implements AxisMproService{
//
//	AxisMproDao AxisMproDao = new AxisMproDaoImpl();
//	CommunicationService  communicationService = new CommunicationServiceImpl();
//	static ResourceBundle res = ResourceBundle.getBundle("application");
//
//	XSSFWorkbook workbook;
//	XSSFSheet sheet;
//	File xlsFile = null;
//	ZipFile zipFile;
//	String fileData;
//	byte[] xmlFileByteArray = null;
//	int rowNum = 0;
//
//
//	@Override
//	public void getAxisMproData(String context) {
//
//		boolean isMailSend=false;
//		try {
////			context.getLogger().log("getAxisMproData method Starts ");
//			List<AxisMproDto> axisMproDataList = AxisMproDao.getAxisMproData(context);
////			List<AxisMproDto> axisMproDataList = new ArrayList<AxisMproDto>();
////			AxisMproDto axisMproDto = new AxisMproDto("12","23","34");
////			AxisMproDto axisMproDto1 = new AxisMproDto("12","23","34");
////			axisMproDataList.add(axisMproDto);
////			axisMproDataList.add(axisMproDto1);
//			
////			context.getLogger().log("record found "+axisMproDataList.size());
////			context.getLogger().log("getAxisMproData method end ");
//
//			if(axisMproDataList!=null && !axisMproDataList.isEmpty())
//			{
//				System.out.println("data write start");
//				writeData(axisMproDataList, context);
//				System.out.println("data write end");
//			}
//			isMailSend=communicationService.sendEmailToUser(fileData, res.getString(Constants.MAIL_TO) ,context);
//			
//		}
//		catch(Exception ex)
//		{
////			context.getLogger().log("Exception in getAxisMproData method "+ex);
//			System.out.println("Exception in getAxisMproData method "+ex);
//		}
//
//	}
//	private double writeData(List<AxisMproDto> axisMproDataList, String context) throws IOException {
//		FileOutputStream fileOut = null;
//		double sizeInMB = 0;
////		context.getLogger().log("axisMproDataList size --: "+axisMproDataList.size());	
//		try {
//			sheet=createExcelHeader();
//			for(int i=0;i<axisMproDataList.size();i++) {
//
//				createRowsInSheet(axisMproDataList.get(i), sheet, context);
//			}
//			xlsFile = new File("D://"+File.separator+"POSV Report.xlsx");
//			System.out.println("File Path"+xlsFile.getAbsolutePath());
//
//			fileOut = new FileOutputStream(xlsFile);
//			workbook.write(fileOut);
//
//			//Convert excel file to password protected zip file
//			zipFile = passwordProtectedZip(xlsFile, context);
//			if(zipFile != null) {
////				context.getLogger().log("converting xlsx file to password protected zip file :: "+zipFile);
//				xmlFileByteArray = convertExcelIntoByteArray(zipFile.getFile(), context);
//			}	
//			fileData=Base64.encode(xmlFileByteArray);
////			context.getLogger().log("Byte Array :: "+fileData);
//
//			long sizeInByte = fileData.length();
//			sizeInMB = sizeInByte/(1024.00*1024.00);
////			context.getLogger().log("Report file size in byte :: "+fileData.length());
////			context.getLogger().log("Report file size in MB :: "+sizeInMB);
//
//		}catch (Exception e) {
//			System.out.println("Exception while writing excel file"+e);
//		}finally {
//			if(fileOut!=null)
//			{
//				workbook.close();
//				fileOut.close();
//			}
//		}
////		context.getLogger().log("SellerTransactionList size outside--: "+axisMproDataList.size());
//	
//
//	return sizeInMB;
//
//	}
//
//private byte[] convertExcelIntoByteArray(File source, String context) {
//	InputStream inputStream = null;
//	ByteArrayOutputStream outputStream ;
//	try {
//		inputStream = new FileInputStream(source);
//		outputStream = new ByteArrayOutputStream();
//
//		int data;
//		while( (data = inputStream.read()) >= 0 ) {
//			outputStream.write(data);
//		}
//
//	}catch(Exception e)
//	{
////		context.getLogger().log("Exception in converting pdf to byte array :: "+e.getMessage());
//		return null;
//	}
//	finally {
//		try {
//			if(inputStream!=null) {
//				inputStream.close();
//			}
//		}
//		catch(Exception ex)
//		{
////			context.getLogger().log("Exception in closing connection :: "+ex.getMessage());
//		}
//	}
//	return outputStream.toByteArray();
//}
//
//private XSSFSheet createExcelHeader() {
//
//
//	workbook = new XSSFWorkbook();
//
//	CellStyle style = workbook.createCellStyle();
//	Font boldFont = workbook.createFont();
//	boldFont.setBold(true);
//	style.setFont(boldFont);
//	style.setAlignment(HorizontalAlignment.CENTER);
//	// Create a blank sheet
//	sheet = workbook.createSheet("Seller Transaction");
//
//	String headers=res.getString("report.file.headers");
//	String[] headerNames=headers.split(Pattern.quote("||"));
//	Row row = sheet.createRow(rowNum++);
//	row.setRowStyle(style);
//	for(int i=0;i<headerNames.length;i++) {
//		Cell cell = row.createCell(i);
//		cell.setCellValue(headerNames[i]);
//		cell.setCellStyle(style);
//	}
//
//
//	return sheet;
//}
//
//
//private void createRowsInSheet(AxisMproDto axisMproDto,XSSFSheet sheet, String context) {
//	Map<String, String> psmResponseMap = new HashMap<String, String>();
//	String psmResponse = StringConstants.RESPONSE_NA;
//
//	// to fetch PSM responses along with their qstId
//
//	Row row=sheet.createRow(rowNum++);
//
//	int cellCount=0;
//	//posvRefNumber
//	Cell cell = row.createCell(cellCount++);
//
//	//POSV Policy Number
//	cell =row.createCell(cellCount++);
//	cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisMproDto.getPolicyNumber()));
//
//	//MFYP
//	cell =row.createCell(cellCount++);
//	cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisMproDto.getTransactionId()));
//
//
//	//SumAssured_CustomerResponse
//	cell =row.createCell(cellCount++);
//	cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisMproDto.getStage()));
//
//	//SURRENDERVALUECUSTOMERRESPONSE
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//GUARANTMATURITYCUSTRESPONSE
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//LockinPeriod_CustomerResponse
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Surrender_or_MaturityBenefit
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Waiting_period_of_180_days
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//PremiumPayAnnually
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Money_Back
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//GSM_CUSTOMER_RESPONSE
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//SellerResponseDateTime
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//PREMIUMPAYMENTTERM1
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//EMAIL_ID_CONFIRMATION
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//RETURNS_NOT_GUARANTEED
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//PERSISTENCY
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//SELF_DECISION
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//RETRIGGER_COUNT
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//PREMIUM_RETURN_ON_MATURITY
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//ANNUITY_OPTIONS
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//FUND_OPTIONS_CONTRIBUTIONS
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//VESTINGAGE_RESPONSE
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//Product Solution
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//
//	//IP address of link receipent
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//IP address of link response
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//	//Customer Link trigger Date & Time - Final Instance
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//
//	//No of attempts (Link trigger to customer)
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//No of attempts (Link trigger to customer)
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Question No.POSV stopped
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Question wise reply(subset)
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//	//Cookie drop o/p
//	cell =row.createCell(cellCount++);
//	cell.setCellValue("NA");
//
//
//
//}
//
///**
// * @param Excel file xlsFile
// * @param context 
// * This method will generate password protected zip file
// * @return ZipFile object containing password protected zip file
// */
//private static ZipFile passwordProtectedZip(File xlsFile, String context) {
//	File file = xlsFile;
//	String zipFilePath =null;
//	ZipFile zipFile = null;
//	String fileName = null;
//	String zipFileName = null;
//	ZipParameters zipParameters = new ZipParameters();
//	try {
//		if(file.exists() && file != null)
//		{
//			fileName = file.getName();
//			zipFileName = fileName.replace("xlsx", "zip");
////			context.getLogger().log("received valid xlsx file");
//			zipFilePath = "D://"+File.separator+zipFileName;	
//			zipFile=new ZipFile(zipFilePath);
//			setZipParams(zipParameters, context); 
//			zipFile.addFile(file,zipParameters);			
//		}
//		else {
////			context.getLogger().log("Exception :: Received invalid xlsx file");
//		}
//	}
//	catch(Exception e) {
////		context.getLogger().log("Exception :: while making password protected zip file "+e.getMessage());
//	}
//	return zipFile;
//}
//
///**
// * @param ZipParameters
// * @param context 
// * This method will apply zip parameters on the provided file
// */
//private static void setZipParams(ZipParameters zipParameters, String context)
//{
//	zipParameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);  
//	zipParameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);   
//	zipParameters.setEncryptFiles(true);  
//	zipParameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);  
//	zipParameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);  
//	zipParameters.setPassword("12345");  
////	context.getLogger().log(" added zip parameters");
//}
//
//
//}
