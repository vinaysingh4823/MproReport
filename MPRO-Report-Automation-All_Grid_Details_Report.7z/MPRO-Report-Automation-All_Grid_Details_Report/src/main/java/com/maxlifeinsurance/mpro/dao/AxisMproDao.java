package com.maxlifeinsurance.mpro.dao;

import java.util.List;

import com.maxlifeinsurance.mpro.dto.AxisMproDto;

public interface AxisMproDao {
	
	public List<AxisMproDto>  getAxisMproData(String context);

}
