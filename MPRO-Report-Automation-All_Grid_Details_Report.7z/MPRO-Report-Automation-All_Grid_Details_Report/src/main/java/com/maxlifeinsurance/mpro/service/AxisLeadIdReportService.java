package com.maxlifeinsurance.mpro.service;

import com.amazonaws.services.lambda.runtime.Context;

public interface AxisLeadIdReportService {
	
	public String generateAxisLeadIdReport(Context context);
}
