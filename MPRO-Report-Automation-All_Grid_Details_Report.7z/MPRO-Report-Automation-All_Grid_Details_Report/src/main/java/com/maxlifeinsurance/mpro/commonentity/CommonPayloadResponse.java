package com.maxlifeinsurance.mpro.commonentity;

import java.io.Serializable;

public class CommonPayloadResponse implements Serializable{

	private static final long serialVersionUID = -2499939894729077405L;

	private String posvRefNumber;
	private String businessMsg;
	public String getPosvRefNumber() {
		return posvRefNumber;
	}
	public void setPosvRefNumber(String posvRefNumber) {
		this.posvRefNumber = posvRefNumber;
	}
	public String getBusinessMsg() {
		return businessMsg;
	}
	public void setBusinessMsg(String businessMsg) {
		this.businessMsg = businessMsg;
	}
	
	
	@Override
	public String toString() {
		return "CommonPayloadResponse [posvRefNumber=" + posvRefNumber + ", businessMsg=" + businessMsg + "]";
	}
}
