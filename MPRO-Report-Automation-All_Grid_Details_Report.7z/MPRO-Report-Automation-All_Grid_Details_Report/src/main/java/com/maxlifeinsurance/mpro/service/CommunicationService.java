package com.maxlifeinsurance.mpro.service;

import com.amazonaws.services.lambda.runtime.Context;

public interface CommunicationService {

	public boolean sendEmailToUser(String xlsFile, String userEmailId, Context context);

}
