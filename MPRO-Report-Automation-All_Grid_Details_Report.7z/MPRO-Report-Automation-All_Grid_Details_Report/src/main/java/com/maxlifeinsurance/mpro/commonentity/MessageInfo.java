package com.maxlifeinsurance.mpro.commonentity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author qualtech
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MessageInfo implements Serializable{

	private static final long serialVersionUID = -2499939894729077405L;
	
	 private String msgCode;
	 private String msg;
	 private String msgDescription;
	 public MessageInfo() {}
	 
	 public MessageInfo(String msgCode, String msg, String msgDescription) {
		super();
		this.msgCode = msgCode;
		this.msg = msg;
		this.msgDescription = msgDescription;
	}

	/**
	 * @return
	 */
	public String getMsgCode() {
	  return msgCode;
	 }

	 /**
	 * @return
	 */
	public String getMsg() {
	  return msg;
	 }

	 /**
	 * @return
	 */
	public String getMsgDescription() {
	  return msgDescription;
	 }

	 /**
	 * @param msgCode
	 */
	public void setMsgCode(String msgCode) {
	  this.msgCode = msgCode;
	 }

	 /**
	 * @param msg
	 */
	public void setMsg(String msg) {
	  this.msg = msg;
	 }

	 /**
	 * @param msgDescription
	 */
	public void setMsgDescription(String msgDescription) {
	  this.msgDescription = msgDescription;
	 }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MessageInfo [msgCode=" + msgCode + ", msg=" + msg + ", msgDescription=" + msgDescription + "]";
	}
	 
}
