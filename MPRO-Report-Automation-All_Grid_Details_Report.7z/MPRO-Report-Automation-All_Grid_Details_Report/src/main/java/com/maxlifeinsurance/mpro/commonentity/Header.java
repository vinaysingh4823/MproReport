package com.maxlifeinsurance.mpro.commonentity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * @author qualtech
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class Header implements Serializable{

	private static final long serialVersionUID = -2499939894729077405L;

	private String correlationId;
	private String appId;

	/**
	 * @return
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * @return
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Header [correlationId=" + correlationId + ", appId=" + appId + "]";
	}
}
