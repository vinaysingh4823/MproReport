package com.maxlifeinsurance.mpro.utils;

import java.text.ParseException;
import java.util.Arrays;

import org.json.JSONObject;

public class Test{
	
	public static void main (String args[]) throws ParseException {

		
		String response = "{\r\n" + 
				"    \"response\": {\r\n" + 
				"        \"responseStatus\": {\r\n" + 
				"            \"timestamp\": 1593271970127,\r\n" + 
				"            \"statusCode\": 200,\r\n" + 
				"            \"statusMessages\": [\r\n" + 
				"                \"Success\"\r\n" + 
				"            ]\r\n" + 
				"        },\r\n" + 
				"        \"responseData\": {\r\n" + 
				"            \"responsePayload\": {\r\n" + 
				"                \"message\": \"Data pushed successfully\"\r\n" + 
				"            }\r\n" + 
				"        }\r\n" + 
				"    }\r\n" + 
				"}";
		JSONObject jsonObject = new JSONObject(response);
		String statusCode = jsonObject.getJSONObject("response").getJSONObject("responseStatus").getInt("statusCode")+"";
		System.out.println("Backflow Status :: "+statusCode);
		
	}
	
	public static String sortString(String inputString) 
    { 
        // convert input string to char array 
        char tempArray[] = inputString.toCharArray(); 
          
        // sort tempArray 
        Arrays.sort(tempArray); 
          
        // return new sorted string 
        return new String(tempArray); 
    } 
}


