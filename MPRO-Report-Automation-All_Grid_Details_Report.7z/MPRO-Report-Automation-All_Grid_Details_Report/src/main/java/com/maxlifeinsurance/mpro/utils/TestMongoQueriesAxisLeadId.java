package com.maxlifeinsurance.mpro.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.ResourceBundle;

import org.bson.Document;
import com.maxlifeinsurance.mpro.config.DbConfig;
import com.maxlifeinsurance.mpro.dto.AxisLeadIdReportDTO;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class TestMongoQueriesAxisLeadId {

	public static void main(String[] args) {
//		final ResourceBundle application = ResourceBundle.getBundle(Constants.APPLICATION);
//		DbConfig dbConfig = new DbConfig();
////		final String sgMongoDbName=application.getString(Constants.MONGODB_NAME);
//		
//		System.out.println("Database name is :: "+sgMongoDbName);
//		
//		
//		Calendar clr=Calendar.getInstance();
//		clr.add(Calendar.DATE, -7);
//		clr.add(Calendar.YEAR, -7);
//		
//		int year=clr.get(Calendar.YEAR);
//		int month=clr.get(Calendar.MONTH);
//		int day=clr.get(Calendar.DATE);
//		
//		Date date=new Date();
//		try {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
//		
//		String dateInString = year+"/"+(month+1)+"/"+(day+1);
//		date = sdf.parse(dateInString);
//		}
//		catch(Exception ec) {
//			ec.printStackTrace();
//		}
	
//		MongoDatabase db = dbConfig.getDbConnection(sgMongoDbName);
//		System.out.println("connected database is :: "+db.toString());
//		MongoCollection coll=db.getCollection("proposal");
//		
//		
////		MongoCollection coll=prposaldb.getCollection("proposal");
//	
//		Document projection=new Document();
//		projection.append("applicationDetails.policyNumber", 1)
//		.append("bancaDetails.leadId", 1)
//		.append("transactionId", 1)
//		.append("applicationDetails.createdTime", 1)
//		.append("channelDetails.channel", 1);
//		
//		 Document whereCondition=new Document();
//		 whereCondition.append("channelDetails.channel", "X").
//		 append("applicationDetails.createdTime",new Document().append("$gte", date));
//		 
//		 
//		 Iterator<Document> resturnObj=coll.find(whereCondition).projection(projection).iterator();
//			while(resturnObj.hasNext()) {
//				System.out.println(resturnObj.next().toJson());
//			}
//			System.out.println(resturnObj);
	}

}
