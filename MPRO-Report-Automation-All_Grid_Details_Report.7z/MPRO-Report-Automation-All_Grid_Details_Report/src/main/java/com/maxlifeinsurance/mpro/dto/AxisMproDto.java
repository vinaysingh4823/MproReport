package com.maxlifeinsurance.mpro.dto;

import java.io.Serializable;

public class AxisMproDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String policyNumber;
	private String transactionId;
	private String stage;
	
	
public AxisMproDto() {
		super();
		this.policyNumber = policyNumber;
		this.transactionId = transactionId;
		this.stage = stage;
	}
	private String createdTime;
	private String branchCode;
	private String firstName;
//	private String posvJourneyStatus;
//	private String lastName;
//	private String premiumMode;
//	private String paymentRenewedBy;
//	private String isPaymentDone;
//	private String spSSNCode;
//	private String afyp;
//	private String atp;
//	private String productName;
//	private String planCode;
//	private String planCodeTPP;
//	private String customerId;
//	private String leadId;
//	private String modalPremium;
//	private String premiumPaymentTerm;
//	private String coverageTerm;
//	private String agentId;
//	private String specifiedPersonCode;
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
//	public String getPosvJourneyStatus() {
//		return posvJourneyStatus;
//	}
//	public void setPosvJourneyStatus(String posvJourneyStatus) {
//		this.posvJourneyStatus = posvJourneyStatus;
//	}
//	public String getLastName() {
//		return lastName;
//	}
//	public void setLastName(String lastName) {
//		this.lastName = lastName;
//	}
//	public String getPremiumMode() {
//		return premiumMode;
//	}
//	public void setPremiumMode(String premiumMode) {
//		this.premiumMode = premiumMode;
//	}
//	public String getPaymentRenewedBy() {
//		return paymentRenewedBy;
//	}
//	public void setPaymentRenewedBy(String paymentRenewedBy) {
//		this.paymentRenewedBy = paymentRenewedBy;
//	}
//	public String getIsPaymentDone() {
//		return isPaymentDone;
//	}
//	public void setIsPaymentDone(String isPaymentDone) {
//		this.isPaymentDone = isPaymentDone;
//	}
//	public String getSpSSNCode() {
//		return spSSNCode;
//	}
//	public void setSpSSNCode(String spSSNCode) {
//		this.spSSNCode = spSSNCode;
//	}
//	public String getAfyp() {
//		return afyp;
//	}
//	public void setAfyp(String afyp) {
//		this.afyp = afyp;
//	}
//	public String getAtp() {
//		return atp;
//	}
//	public void setAtp(String atp) {
//		this.atp = atp;
//	}
//	public String getProductName() {
//		return productName;
//	}
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}
//	public String getPlanCode() {
//		return planCode;
//	}
//	public void setPlanCode(String planCode) {
//		this.planCode = planCode;
//	}
//	public String getPlanCodeTPP() {
//		return planCodeTPP;
//	}
//	public void setPlanCodeTPP(String planCodeTPP) {
//		this.planCodeTPP = planCodeTPP;
//	}
//	public String getCustomerId() {
//		return customerId;
//	}
//	public void setCustomerId(String customerId) {
//		this.customerId = customerId;
//	}
//	public String getLeadId() {
//		return leadId;
//	}
//	public void setLeadId(String leadId) {
//		this.leadId = leadId;
//	}
//	public String getModalPremium() {
//		return modalPremium;
//	}
//	public void setModalPremium(String modalPremium) {
//		this.modalPremium = modalPremium;
//	}
//	public String getPremiumPaymentTerm() {
//		return premiumPaymentTerm;
//	}
//	public void setPremiumPaymentTerm(String premiumPaymentTerm) {
//		this.premiumPaymentTerm = premiumPaymentTerm;
//	}
//	public String getCoverageTerm() {
//		return coverageTerm;
//	}
//	public void setCoverageTerm(String coverageTerm) {
//		this.coverageTerm = coverageTerm;
//	}
//	public String getAgentId() {
//		return agentId;
//	}
//	public void setAgentId(String agentId) {
//		this.agentId = agentId;
//	}
//	public String getSpecifiedPersonCode() {
//		return specifiedPersonCode;
//	}
//	public void setSpecifiedPersonCode(String specifiedPersonCode) {
//		this.specifiedPersonCode = specifiedPersonCode;
//	}
	@Override
	public String toString() {
		return "AxisMproDto [policyNumber=" + policyNumber + ", transactionId=" + transactionId + ", stage=" + stage
				+ ", createdTime=" + createdTime + ", branchCode=" + branchCode + ", firstName=" + firstName + "]";
	}
	
	

}
