package com.maxlifeinsurance.mpro.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.maxlifeinsurance.mpro.service.AxisLeadIdReportService;
import com.maxlifeinsurance.mpro.serviceimpl.AxisLeadIdReportServiceImpl;

public class AxisLeadIdReportGenerationHandler {

	AxisLeadIdReportService axisLeadIdReportService = new AxisLeadIdReportServiceImpl();

	public Void handleRequest(Context context) {
		context.getLogger().log("Axis leadId report handler is starting...");
		try {
			String response = axisLeadIdReportService.generateAxisLeadIdReport(context);
			context.getLogger().log("Axis leadId report generation status is :: " + response);
		} catch (Exception ex) {
			context.getLogger().log("Exception while executing axis leadId report handler :: " + ex.getMessage());
		}
		return null;
	}
}
