//package com.maxlifeinsurance.mpro.handler;
//
//import com.maxlifeinsurance.mpro.service.AxisMproService;
//import com.maxlifeinsurance.mpro.serviceimpl.AxisMproServiceImpl;
//
//public class AxisMproHandler {
//
//	AxisMproService axisMproService = new AxisMproServiceImpl();
//	public void handleRequest(String context) {
//    	try{
////    	context.getLogger().log("Axis Mpro Handler Start ");
//    	axisMproService.getAxisMproData(context);
//    	}catch(Exception ex) {
//    		
//    	}
//    }
//}
