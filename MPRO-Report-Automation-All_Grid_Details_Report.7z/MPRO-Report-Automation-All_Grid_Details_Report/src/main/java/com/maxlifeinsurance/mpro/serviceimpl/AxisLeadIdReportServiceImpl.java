package com.maxlifeinsurance.mpro.serviceimpl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.amazonaws.services.lambda.runtime.Context;
import com.maxlifeinsurance.mpro.dao.AxisLeadIdReportDao;
import com.maxlifeinsurance.mpro.daoimpl.AxisLeadIdReportDaoImpl;
import com.maxlifeinsurance.mpro.dto.AxisLeadIdReportDTO;
import com.maxlifeinsurance.mpro.service.AxisLeadIdReportService;
import com.maxlifeinsurance.mpro.service.CommunicationService;
import com.maxlifeinsurance.mpro.utils.AWSClients;
import com.maxlifeinsurance.mpro.utils.Constants;
import com.maxlifeinsurance.mpro.utils.StringUtility;
import com.opencsv.CSVWriter;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

public class AxisLeadIdReportServiceImpl implements AxisLeadIdReportService {

	CommunicationService communicationService = new CommunicationServiceImpl();
	static ResourceBundle res = ResourceBundle.getBundle("application");

	XSSFWorkbook workbook;
	XSSFSheet sheet;
	File xlsFile = null;
	File file = null;
	ZipFile zipFile;
	String fileData;
	byte[] xmlFileByteArray = null;
	static int rowNum = 0;

	@Override
	public String generateAxisLeadIdReport(Context context) {
		String status = "Fail";
		double fileSize = 0.0;
		AxisLeadIdReportDao axisLeadDao = new AxisLeadIdReportDaoImpl();
		try {
			List<AxisLeadIdReportDTO> axisLeadList = axisLeadDao.getAxisLeadIdReportData(context);
			context.getLogger().log("Size of Document received is :: " + axisLeadList.size());
			if (axisLeadList != null && !axisLeadList.isEmpty()) {
				fileSize = axisLeadIdCsvWriter(axisLeadList, context);
				context.getLogger().log("Report size is :: " + fileSize);
				if (fileSize < 12.0
						&& communicationService.sendEmailToUser(fileData, System.getenv(Constants.MAIL_TO), context)) {
					context.getLogger().log("Mail sent successfully");
				} else {
					AWSClients.saveFileToS3(file, res.getString(Constants.S3BUCKETNAME), context);
					context.getLogger().log("File is saved on S3 bucket with name :: " + res.getString(Constants.S3BUCKETNAME));
				}
			}

		} catch (Exception ex) {
			context.getLogger().log("Exception while generating report :: " + ex.getMessage());
		}
		return status;
	}

	
	private double axisLeadIdCsvWriter(List<AxisLeadIdReportDTO> axisLeadIdReportDtoList, Context context){
		double sizeInMb = 0;
		FileWriter outputfile = null;
		CSVWriter writer = null;
		try {
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss");
			LocalDateTime toDate = LocalDateTime.now();
			file = new File("/tmp" + File.separator + "Axis Lead Report-" + (dateTimeFormatter.format(toDate)) + ".csv");
			context.getLogger().log("File Path" + xlsFile.getAbsolutePath());
			outputfile = new FileWriter(file); 
			writer = new CSVWriter(outputfile); 
			List<String[]> data = new ArrayList<String[]>();
			data.add(res.getString("report.file.headers").split(Pattern.quote("||")));
			for(AxisLeadIdReportDTO axisLeadIdReportDto : axisLeadIdReportDtoList){
				String row = StringUtility.checkStringNullOrBlankWithoutCase(axisLeadIdReportDto.getCreatedTime()) + "," +
							 StringUtility.checkStringNullOrBlankWithoutCase(axisLeadIdReportDto.getPolicyNumber())+ "," +
							 StringUtility.checkStringNullOrBlankWithoutCase(axisLeadIdReportDto.getLeadId())+ "," +
							 StringUtility.checkStringNullOrBlankWithoutCase(axisLeadIdReportDto.getChannel())+ "," +
							 StringUtility.checkStringNullOrBlankWithoutCase(axisLeadIdReportDto.getTransactionId());
				data.add(row.split(Pattern.quote(",")));
						     
			}
			writer.writeAll(data);
			writer.close();
			context.getLogger().log("CSV Created Successfully");
			zipFile = passwordProtectedZip(file, null);
			if (zipFile != null) {
				context.getLogger().log("Converting csv file to password protected zip file :: "+zipFile);
				xmlFileByteArray = convertExcelIntoByteArray(zipFile.getFile(), null);
			}
			fileData = Base64.encode(xmlFileByteArray);
			long sizeInByte = fileData.length();
			sizeInMb = sizeInByte / (1024.00 * 1024.00);
			context.getLogger().log("Size of file is :: "+sizeInMb);

		} catch (Exception ex) {
			context.getLogger().log("Exception occured while creating report for Axis Lead ID :: "+ex.getMessage());
		} finally {
			try {
				if (outputfile != null) {
					outputfile.close();
				}
				if (writer != null) {
					writer.close();
				}
			} catch (Exception ex) {
				 context.getLogger().log("Exception occured while closing object :: "+ex.getMessage());
			}
		}
		return sizeInMb;
	
		
	}
	
	private double getReport(List<AxisLeadIdReportDTO> axisLeadList, Context context) throws IOException {
		FileOutputStream fileOut = null;
		double sizeInMB = 0;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss");
		LocalDateTime toDate = LocalDateTime.now();
		try {
			context.getLogger().log("To create report");
			sheet = createExcelHeader();
			for (int i = 0; i < axisLeadList.size(); i++) {
				createRowsInSheet(axisLeadList.get(i), sheet, context);
			}
			xlsFile = new File(
					"/tmp" + File.separator + "Axis Lead Report-" + (dateTimeFormatter.format(toDate)) + ".xlsx");
			context.getLogger().log("File Path" + xlsFile.getAbsolutePath());

			fileOut = new FileOutputStream(xlsFile);
			workbook.write(fileOut);

			zipFile = passwordProtectedZip(xlsFile, context);
			if (zipFile != null) {
				// context.getLogger().log("converting xlsx file to password
				// protected zip file :: "+zipFile);
				xmlFileByteArray = convertExcelIntoByteArray(zipFile.getFile(), context);
			}
			fileData = Base64.encode(xmlFileByteArray);

			long sizeInByte = fileData.length();
			sizeInMB = sizeInByte / (1024.00 * 1024.00);
			context.getLogger().log("Size of file is :: " + sizeInMB);
		} catch (Exception ex) {
			context.getLogger().log("Exception in creating excel file :: " + ex.getMessage());
		} finally {
			if (fileOut != null) {
				workbook.close();
				fileOut.close();
			}
		}
		return sizeInMB;
	}

	private void createRowsInSheet(AxisLeadIdReportDTO axisLeadDto, XSSFSheet sheet, Context context) {
		try {
			Row row = sheet.createRow(rowNum++);
			int cellCount = 0;
			Cell cell = null;

			// Application.createdTime
			cell = row.createCell(cellCount++);
			cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisLeadDto.getCreatedTime()));

			// Application.policyNumber
			cell = row.createCell(cellCount++);
			cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisLeadDto.getPolicyNumber()));

			// BancaDetails.leadId
			cell = row.createCell(cellCount++);
			cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisLeadDto.getLeadId()));

			// ChannelDetails.channel
			cell = row.createCell(cellCount++);
			cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisLeadDto.getChannel()));

			// TransactionId
			cell = row.createCell(cellCount++);
			cell.setCellValue(StringUtility.checkStringNullOrBlankWithoutCase(axisLeadDto.getTransactionId()));

		} catch (Exception ex) {
			context.getLogger().log("Exception while creating rows in report :: " + ex.getMessage());
		}

	}

	private XSSFSheet createExcelHeader() {
		workbook = new XSSFWorkbook();
		CellStyle style = workbook.createCellStyle();
		Font boldFont = workbook.createFont();
		boldFont.setBold(true);
		style.setFont(boldFont);
		style.setAlignment(HorizontalAlignment.CENTER);
		// Create a blank sheet
		sheet = workbook.createSheet("Axis Lead Id");

		String headers = res.getString("report.file.headers");
		String[] headerNames = headers.split(Pattern.quote("||"));
		Row row = sheet.createRow(rowNum++);
		row.setRowStyle(style);
		for (int i = 0; i < headerNames.length; i++) {
			Cell cell = row.createCell(i);
			cell.setCellValue(headerNames[i]);
			cell.setCellStyle(style);
		}
		return sheet;
	}

	private byte[] convertExcelIntoByteArray(File source, Context context) {
		InputStream inputStream = null;
		ByteArrayOutputStream outputStream;
		try {
			inputStream = new FileInputStream(source);
			outputStream = new ByteArrayOutputStream();

			int data;
			while ((data = inputStream.read()) >= 0) {
				outputStream.write(data);
			}

		} catch (Exception e) {
			context.getLogger().log("Exception in converting pdf to byte array :: " + e.getMessage());
			return null;
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (Exception ex) {
				context.getLogger().log("Exception in closing connection :: " + ex.getMessage());
			}
		}
		return outputStream.toByteArray();
	}

	private static ZipFile passwordProtectedZip(File xlsFile, Context context) {
		File file = xlsFile;
		String zipFilePath = null;
		ZipFile zipFile = null;
		String fileName = null;
		String zipFileName = null;
		ZipParameters zipParameters = new ZipParameters();
		try {
			if (file.exists() && file != null) {
				fileName = file.getName();
				zipFileName = fileName.replace("csv", "zip");
				context.getLogger().log("Received valid CSV file");
				zipFilePath = "/tmp" + File.separator + zipFileName;
				zipFile = new ZipFile(zipFilePath);
				setZipParams(zipParameters, context);
				zipFile.addFile(file, zipParameters);
			} else {
				context.getLogger().log("Exception :: Received invalid csv file");
			}
		} catch (Exception e) {
			context.getLogger().log("Exception :: while making password protected zip file " + e.getMessage());
		}
		return zipFile;
	}

	private static void setZipParams(ZipParameters zipParameters, Context context) {
		zipParameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		zipParameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		zipParameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		zipParameters.setPassword("max2020");
		context.getLogger().log("added zip parameters");
	}

}
