package com.maxlifeinsurance.mpro.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public class MultiFormatDate 
{
	public static String formatTimeStampToIsoDateFormat(String requestDate){
		String otpDateStr="";
		try{
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
		      Date lFromDate1 = datetimeFormatter1.parse(requestDate);
		      Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		      Date date= new Date((fromTS1).getTime());
			if(date!=null){
				TimeZone tz = TimeZone.getTimeZone("UTC");
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
				df.setTimeZone(tz);
				otpDateStr = df.format(date);
			}
		}catch(Exception e){
		}
		return otpDateStr;
	}
	
	public static String formatDateInMongoDateFormat(String requestDate) {
		String mongoDate = "";
		try {
			if (requestDate != null && !requestDate.isEmpty()) {
				SimpleDateFormat sdf = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
				Date date = sdf.parse(requestDate);
				SimpleDateFormat mongpDtFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				mongoDate = mongpDtFormat.format(date);
			}

		} catch (Exception e) {

		}
		return mongoDate;
	}
	
}
