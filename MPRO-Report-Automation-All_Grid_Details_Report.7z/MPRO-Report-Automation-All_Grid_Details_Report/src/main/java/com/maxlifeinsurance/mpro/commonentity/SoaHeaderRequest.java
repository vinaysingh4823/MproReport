package com.maxlifeinsurance.mpro.commonentity;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author qualtech
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"soaCorrelationId",
	"soaMsgVersion",
	"soaAppId"
})
@JsonIgnoreProperties(ignoreUnknown=true)
public class SoaHeaderRequest implements Serializable{

	private static final long serialVersionUID = -2499939894729077405L;
	@JsonProperty("soaCorrelationId")
	private String soaCorrelationId;
	@JsonProperty("soaAppId")
	private String soaAppId;
	@JsonProperty("soaMsgVersion")
	private String soaMsgVersion;
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	@Override
	public String toString() {
		return "SoaHeaderRequest [soaCorrelationId=" + soaCorrelationId + ", soaAppId=" + soaAppId + ", soaMsgVersion="
				+ soaMsgVersion + "]";
	}
}
