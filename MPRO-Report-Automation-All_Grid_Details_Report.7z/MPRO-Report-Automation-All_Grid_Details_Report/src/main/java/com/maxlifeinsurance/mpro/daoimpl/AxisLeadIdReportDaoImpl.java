package com.maxlifeinsurance.mpro.daoimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.bson.Document;

import com.amazonaws.services.lambda.runtime.Context;
import com.maxlifeinsurance.mpro.config.DbConfig;
import com.maxlifeinsurance.mpro.dao.AxisLeadIdReportDao;
import com.maxlifeinsurance.mpro.dto.AxisLeadIdReportDTO;
import com.maxlifeinsurance.mpro.utils.Constants;
import com.maxlifeinsurance.mpro.utils.Queries;
import com.maxlifeinsurance.mpro.utils.StringConstants;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class AxisLeadIdReportDaoImpl implements AxisLeadIdReportDao {

	private ResourceBundle application = ResourceBundle.getBundle(Constants.APPLICATION);
	private String mongoDbName = application.getString(Constants.MONGODB_DBNAME);
	private String mongoCollectionName = application.getString(Constants.MONGO_COLLECTION);

	@Override
	public List<AxisLeadIdReportDTO> getAxisLeadIdReportData(Context context) {
		List<AxisLeadIdReportDTO> axisLeadList = null;
		try {
			context.getLogger().log("To fetch report data from mongoDB");
			axisLeadList = getAxisLeadMongoData(context);
		} catch (Exception ex) {
			context.getLogger().log("Exception in getting report data :: " + ex.getMessage());
		}
		return axisLeadList;
	}

	/**
	 * 
	 * @param context
	 * @return
	 */
	private List<AxisLeadIdReportDTO> getAxisLeadMongoData(Context context) {
		List<AxisLeadIdReportDTO> axisLeadList = null;
		try {
			context.getLogger().log("Connecting to mongoDB");
			MongoDatabase db = new DbConfig().getDbConnection(mongoDbName, context);
			MongoCollection collection = db.getCollection(mongoCollectionName);
			axisLeadList = getAllDocuments(db, collection, context);

			context.getLogger().log("Succesfully received all data from mongoDB :: " + mongoDbName + " collection is "
					+ mongoCollectionName);
		} catch (Exception ex) {
			context.getLogger().log("Exception in connecting to mongo :: " + ex.getMessage());
		}
		return axisLeadList;
	}

	/**
	 * 
	 * @param db
	 * @param collection
	 * @param context
	 * @return
	 */
	public List<AxisLeadIdReportDTO> getAllDocuments(MongoDatabase db, MongoCollection<Document> collection,
			Context context) {
		List<AxisLeadIdReportDTO> axisLeadList = new ArrayList<AxisLeadIdReportDTO>();
		try {
			context.getLogger().log("To fetch document from mongoDB");
			Calendar clr = Calendar.getInstance();
			clr.add(Calendar.DATE, -7);
			clr.add(Calendar.YEAR, -7);
			int year = clr.get(Calendar.YEAR);
			int month = clr.get(Calendar.MONTH);
			int day = clr.get(Calendar.DATE);
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String dateInString = year + "/" + (month + 1) + "/" + (day + 1);
			date = sdf.parse(dateInString);

			Document projection = new Document();
			projection.append(Queries.POLICY_NUMBER, 1).append(Queries.BANCA_LEADID, 1)
					.append(Queries.TRANSACTION_ID, 1).append(Queries.CREATED_DATE, 1).append(Queries.CHANNEL, 1);

			Document whereCondition = new Document();
			whereCondition.append(Queries.CHANNEL, StringConstants.CHANNEL_NAME).append(Queries.CREATED_DATE,
					new Document().append("$gte", date));

			Iterator<Document> response = collection.find(whereCondition).projection(projection).iterator();
			while (response.hasNext()) {
				axisLeadList.add(putData(response.next(), context));
			}

			context.getLogger().log("Size of received documents is :: " + axisLeadList.size());
		} catch (Exception ex) {
			context.getLogger().log("Exception while fetching document from collection :: " + ex.getMessage());
		}
		return axisLeadList;
	}

	private AxisLeadIdReportDTO putData(Document document, Context context) {
		AxisLeadIdReportDTO axisLeadDto = new AxisLeadIdReportDTO();
		try {
			if (document.containsKey(StringConstants.CHANNEL_DETAILS) && document
					.get(StringConstants.CHANNEL_DETAILS, Document.class).containsKey(StringConstants.CHANNEL)) {
				axisLeadDto.setChannel(document.get(StringConstants.CHANNEL_DETAILS, Document.class)
						.getString(StringConstants.CHANNEL));
			}

			if (document.containsKey(StringConstants.APPLICATION_DETAILS)
					&& document.get(StringConstants.APPLICATION_DETAILS, Document.class)
							.containsKey(StringConstants.POLICY_NUMBER)) {
				axisLeadDto.setPolicyNumber(document.get(StringConstants.APPLICATION_DETAILS, Document.class)
						.getString(StringConstants.POLICY_NUMBER));
			}

			if (document.containsKey(StringConstants.APPLICATION_DETAILS)
					&& document.get(StringConstants.APPLICATION_DETAILS, Document.class)
							.containsKey(StringConstants.CREATED_TIME)) {
				axisLeadDto.setCreatedTime(document.get(StringConstants.APPLICATION_DETAILS, Document.class)
						.getDate(StringConstants.CREATED_TIME).toString());
			}
			if (document.containsKey(StringConstants.BANCA_DETAILS) && document
					.get(StringConstants.BANCA_DETAILS, Document.class).containsKey(StringConstants.LEAD_ID)) {
				axisLeadDto.setLeadId(
						document.get(StringConstants.BANCA_DETAILS, Document.class).getString(StringConstants.LEAD_ID));
			}

			if (document.containsKey(StringConstants.TRANSACTION_ID)
					&& document.get(StringConstants.TRANSACTION_ID) != null) {
				axisLeadDto.setTransactionId(document.get(StringConstants.TRANSACTION_ID).toString());
			}
		} catch (Exception ex) {
			context.getLogger().log("Exception in putdata method :: " + ex.getMessage());
		}
		return axisLeadDto;
	}
}
