package com.maxlifeinsurance.mpro.service;

import com.amazonaws.services.lambda.runtime.Context;

public interface AxisMproService {

	public void getAxisMproData(String context) ;
}
