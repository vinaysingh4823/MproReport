package com.maxlifeinsurance.mpro.config;

//import com.maxlifeinsurance.mpro.service.AxisMproService;
//import com.maxlifeinsurance.mpro.serviceimpl.AxisMproServiceImpl;

public class ApplicationStartUp {

//	AxisMproService axisMproService = new AxisMproServiceImpl();

    
	public static void main(String[] args) {
		System.out.println("application start");
        
//		AxisMproService axisMproService = new AxisMproServiceImpl();
//		axisMproService.getAxisMproData(null);
//		System.out.println("application end");

	}

}
