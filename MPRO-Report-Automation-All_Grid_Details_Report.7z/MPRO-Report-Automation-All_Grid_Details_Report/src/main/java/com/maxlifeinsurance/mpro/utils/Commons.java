package com.maxlifeinsurance.mpro.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Commons {

	public static String getFormatedDate()
	{
		try 
		{
			String opFormat="dd-MMM-yyyy";
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat(opFormat);
			return sdf.format(date);
		} 
		catch (Exception e) 
		{
			return "";
		}
	}
}
